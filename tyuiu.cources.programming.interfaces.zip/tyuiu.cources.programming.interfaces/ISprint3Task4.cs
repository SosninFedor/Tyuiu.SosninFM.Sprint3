﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint3
{
    public interface ISprint3Task4V0 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V1 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V2 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V3 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V4 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V5 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V6 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V7 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V8 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V9 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V10 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V11 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V12 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V13 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V14 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V15 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V16 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V17 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V18 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V19 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V20 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V21 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V22 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V23 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V24 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V25 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V26 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V27 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V28 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V29 { double Calculate(int startValue, int stopValue); }
    public interface ISprint3Task4V30 { double Calculate(int startValue, int stopValue); }
}