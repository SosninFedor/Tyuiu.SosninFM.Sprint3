﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint3
{
    public interface ISprint3Task1V0 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V1 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task1V2 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task1V3 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task1V4 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task1V5 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task1V6 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V7 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V8 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V9 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V10 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V11 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V12 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V13 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V14 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V15 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V16 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V17 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V18 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task1V19 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V20 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task1V21 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V22 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V23 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V24 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V25 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V26 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task1V27 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V28 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V29 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task1V30 { double GetSumSeries(double value, int startValue, int stopValue); }






}
