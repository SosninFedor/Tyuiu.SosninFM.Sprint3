﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint99
{
    public interface ISprint99Task99V99 { string GenerateTxtFile(); }

}