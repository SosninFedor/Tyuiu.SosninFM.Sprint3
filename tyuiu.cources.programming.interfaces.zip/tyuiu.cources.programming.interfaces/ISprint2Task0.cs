﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint2
{
    public interface ISprint2Task0V0 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V1 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V2 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V3 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V4 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V5 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V6 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V7 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V8 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V9 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V10 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V11 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V12 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V13 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V14 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V15 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V16 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V17 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V18 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V19 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V20 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V21 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V22 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V23 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V24 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V25 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V26 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V27 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V28 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V29 {bool[] GetCompareOperations(int x, int y); }
    public interface ISprint2Task0V30 {bool[] GetCompareOperations(int x, int y); }
}
