﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint1
{
    public interface ISprint1Task7V0 { double Calculate(double x, double y, double z); }
    public interface ISprint1Task7V1 { double Calculate(double a, double b, double c); }
    public interface ISprint1Task7V2 { double Calculate(double x, double y); }
    public interface ISprint1Task7V3 { double Calculate(double x, double y); }
    public interface ISprint1Task7V4 { double Calculate(double x, double y); }
    public interface ISprint1Task7V5 { double Calculate(double x); }
    public interface ISprint1Task7V6 { double Calculate(double x, double y); }
    public interface ISprint1Task7V7 { double Calculate(double x, double y); }
    public interface ISprint1Task7V8 { double Calculate(double x, double y); }
    public interface ISprint1Task7V9 { double Calculate(double x, double y); }
    public interface ISprint1Task7V10 { double Calculate(double x); }
    public interface ISprint1Task7V11 { double Calculate(double x, double y); }
    public interface ISprint1Task7V12 { double Calculate(double x, double y); }
    public interface ISprint1Task7V13 { double Calculate(double x, double y); }
    public interface ISprint1Task7V14 { double Calculate(double x, double y); }
    public interface ISprint1Task7V15 { double Calculate(double x); }
    public interface ISprint1Task7V16 { double Calculate(double x); }
    public interface ISprint1Task7V17 { double Calculate(double x, double y); }
    public interface ISprint1Task7V18 { double Calculate(double x, double y); }
    public interface ISprint1Task7V19 { double Calculate(double x); }
    public interface ISprint1Task7V20 { double Calculate(double x, double y); }
    public interface ISprint1Task7V21 { double Calculate(double x, double y); }
    public interface ISprint1Task7V22 { double Calculate(double x, double y); }
    public interface ISprint1Task7V23 { double Calculate(double x, double y); }
    public interface ISprint1Task7V24 { double Calculate(double x, double y); }
    public interface ISprint1Task7V25 { double Calculate(double x, double y); }
    public interface ISprint1Task7V26 { double Calculate(double x, double y); }
    public interface ISprint1Task7V27 { double Calculate(double x, double y); }
    public interface ISprint1Task7V28 { double Calculate(double x, double y); }
    public interface ISprint1Task7V29 { double Calculate(double x, double y); }
    public interface ISprint1Task7V30 { double Calculate(double x, double y); }
}
