﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint1
{
    public interface ISprint1Task0V0 { double Calculate(); }
    public interface ISprint1Task0V1 { double Calculate(); }
    public interface ISprint1Task0V2 { double Calculate(); }
    public interface ISprint1Task0V3 { double Calculate(); }
    public interface ISprint1Task0V4 { double Calculate(); }
    public interface ISprint1Task0V5 { double Calculate(); }
    public interface ISprint1Task0V6 { double Calculate(); }
    public interface ISprint1Task0V7 { double Calculate(); }
    public interface ISprint1Task0V8 { double Calculate(); }
    public interface ISprint1Task0V9 { double Calculate(); }
    public interface ISprint1Task0V10 { double Calculate(); }
    public interface ISprint1Task0V11 { double Calculate(); }
    public interface ISprint1Task0V12 { double Calculate(); }
    public interface ISprint1Task0V13 { double Calculate(); }
    public interface ISprint1Task0V14 { double Calculate(); }
    public interface ISprint1Task0V15 { double Calculate(); }
    public interface ISprint1Task0V16 { double Calculate(); }
    public interface ISprint1Task0V17 { double Calculate(); }
    public interface ISprint1Task0V18 { double Calculate(); }
    public interface ISprint1Task0V19 { double Calculate(); }
    public interface ISprint1Task0V20 { double Calculate(); }
    public interface ISprint1Task0V21 { double Calculate(); }
    public interface ISprint1Task0V22 { double Calculate(); }
    public interface ISprint1Task0V23 { double Calculate(); }
    public interface ISprint1Task0V24 { double Calculate(); }
    public interface ISprint1Task0V25 { double Calculate(); }
    public interface ISprint1Task0V26 { double Calculate(); }
    public interface ISprint1Task0V27 { double Calculate(); }
    public interface ISprint1Task0V28 { double Calculate(); }
    public interface ISprint1Task0V29 { double Calculate(); }
    public interface ISprint1Task0V30 { double Calculate(); }
}
