﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint2
{
    public interface ISprint2Task2V0 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V1 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V2 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V3 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V4 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V5 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V6 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V7 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V8 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V9 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V10 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V11 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V12 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V13 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V14 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V15 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V16 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V17 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V18 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V19 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V20 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V21 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V22 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V23 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V24 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V25 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V26 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V27 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V28 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V29 { bool CheckDotInShadedArea(int x, int y); }
    public interface ISprint2Task2V30 { bool CheckDotInShadedArea(int x, int y); }
}
