﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint2
{
    public interface ISprint2Task3V0 { double Calculate(double x); }
    public interface ISprint2Task3V1 { double Calculate(double x); }
    public interface ISprint2Task3V2 { double Calculate(double x); }
    public interface ISprint2Task3V3 { double Calculate(double x); }
    public interface ISprint2Task3V4 { double Calculate(double x); }
    public interface ISprint2Task3V5 { double Calculate(double x); }
    public interface ISprint2Task3V6 { double Calculate(double x); }
    public interface ISprint2Task3V7 { double Calculate(double x); }
    public interface ISprint2Task3V8 { double Calculate(double x); }
    public interface ISprint2Task3V9 { double Calculate(double x); }
    public interface ISprint2Task3V10 { double Calculate(double x); }
    public interface ISprint2Task3V11 { double Calculate(double x); }
    public interface ISprint2Task3V12 { double Calculate(double x); }
    public interface ISprint2Task3V13 { double Calculate(double x); }
    public interface ISprint2Task3V14 { double Calculate(double x); }
    public interface ISprint2Task3V15 { double Calculate(double x); }
    public interface ISprint2Task3V16 { double Calculate(double x); }
    public interface ISprint2Task3V17 { double Calculate(double x); }
    public interface ISprint2Task3V18 { double Calculate(double x); }
    public interface ISprint2Task3V19 { double Calculate(double x); }
    public interface ISprint2Task3V20 { double Calculate(double x); }
    public interface ISprint2Task3V21 { double Calculate(double x); }
    public interface ISprint2Task3V22 { double Calculate(double x); }
    public interface ISprint2Task3V23 { double Calculate(double x); }
    public interface ISprint2Task3V24 { double Calculate(double x); }
    public interface ISprint2Task3V25 { double Calculate(double x); }
    public interface ISprint2Task3V26 { double Calculate(double x); }
    public interface ISprint2Task3V27 { double Calculate(double x); }
    public interface ISprint2Task3V28 { double Calculate(double x); }
    public interface ISprint2Task3V29 { double Calculate(double x); }
    public interface ISprint2Task3V30 { double Calculate(double x); }

}
