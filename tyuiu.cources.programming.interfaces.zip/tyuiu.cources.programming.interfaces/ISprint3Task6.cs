﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint3
{
    public interface ISprint3Task6V0 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V1 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V2 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V3 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V4 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V5 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V6 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V7 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V8 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V9 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V10 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V11 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V12 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V13 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V14 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V15 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V16 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V17 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V18 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V19 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V20 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V21 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V22 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V23 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V24 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V25 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V26 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V27 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V28 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V29 { int GetSumTheDivisors(int startValue, int stopValue); }
    public interface ISprint3Task6V30 { int GetSumTheDivisors(int startValue, int stopValue); }
}
