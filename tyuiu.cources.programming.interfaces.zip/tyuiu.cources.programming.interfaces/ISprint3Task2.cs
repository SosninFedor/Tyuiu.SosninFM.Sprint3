﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint3
{
    public interface ISprint3Task2V0 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V1 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task2V2 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task2V3 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V4 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task2V5 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V6 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V7 { double GetSumSeries(int startValue, int stopValue); }    
    public interface ISprint3Task2V8 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task2V9 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V10 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V11 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V12 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V13 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V14 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task2V15 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V16 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V17 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task2V18 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V19 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task2V20 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V21 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V22 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V23 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V24 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V25 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V26 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V27 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task2V28 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task2V29 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task2V30 { double GetMultiplySeries(double value, int startValue, int stopValue); }
}
