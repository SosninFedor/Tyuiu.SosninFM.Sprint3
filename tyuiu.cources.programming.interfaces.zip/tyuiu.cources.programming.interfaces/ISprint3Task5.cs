﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint3
{
    public interface ISprint3Task5V0 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V1  { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V2  { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V3  { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V4  { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V5  { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V6  { double GetSumSumSeries(int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V7  { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V8  { double GetSumSumSeries(int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V9  { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V10 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V11 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V12 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V13 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V14 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V15 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V16 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V17 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V18 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V19 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V20 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V21 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V22 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V23 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V24 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V25 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V26 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V27 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V28 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V29 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }
    public interface ISprint3Task5V30 { double GetSumSumSeries(int x, int startValue1, int startValue2, int stopValue1, int stopValue2); }

}