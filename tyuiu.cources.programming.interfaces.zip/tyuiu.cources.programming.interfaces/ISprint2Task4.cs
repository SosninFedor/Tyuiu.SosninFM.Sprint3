﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint2
{
    public interface ISprint2Task4V0 { double Calculate(double x, double y); }
    public interface ISprint2Task4V1 { double Calculate(double x, double y); }
    public interface ISprint2Task4V2 { double Calculate(double x, double y); }
    public interface ISprint2Task4V3 { double Calculate(double x, double y); }
    public interface ISprint2Task4V4 { double Calculate(double x, double y); }
    public interface ISprint2Task4V5 { double Calculate(double x, double y); }
    public interface ISprint2Task4V6 { double Calculate(double x, double y); }
    public interface ISprint2Task4V7 { double Calculate(double x, double y); }
    public interface ISprint2Task4V8 { double Calculate(double x, double y); }
    public interface ISprint2Task4V9 { double Calculate(double x, double y); }
    public interface ISprint2Task4V10 { double Calculate(double x, double y); }
    public interface ISprint2Task4V11 { double Calculate(double x, double y); }
    public interface ISprint2Task4V12 { double Calculate(double x, double y); }
    public interface ISprint2Task4V13 { double Calculate(double x, double y); }
    public interface ISprint2Task4V14 { double Calculate(double x, double y); }
    public interface ISprint2Task4V15 { double Calculate(double x, double y); }
    public interface ISprint2Task4V16 { double Calculate(double x, double y); }
    public interface ISprint2Task4V17 { double Calculate(double x, double y); }
    public interface ISprint2Task4V18 { double Calculate(double x, double y); }
    public interface ISprint2Task4V19 { double Calculate(double x, double y); }
    public interface ISprint2Task4V20 { double Calculate(double x, double y); }
    public interface ISprint2Task4V21 { double Calculate(double x, double y); }
    public interface ISprint2Task4V22 { double Calculate(double x, double y); }
    public interface ISprint2Task4V23 { double Calculate(double x, double y); }
    public interface ISprint2Task4V24 { double Calculate(double x, double y); }
    public interface ISprint2Task4V25 { double Calculate(double x, double y); }
    public interface ISprint2Task4V26 { double Calculate(double x, double y); }
    public interface ISprint2Task4V27 { double Calculate(double x, double y); }
    public interface ISprint2Task4V28 { double Calculate(double x, double y); }
    public interface ISprint2Task4V29 { double Calculate(double x, double y); }
    public interface ISprint2Task4V30 { double Calculate(double x, double y); }

}
