﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint2
{
    public interface ISprint2Task7V0 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V1 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V2 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V3 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V4 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V5 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V6 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V7 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V8 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V9 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V10 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V11 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V12 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V13 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V14 { bool CheckDotInShadedArea(double x, double y); }
    public interface ISprint2Task7V15 { bool CheckDotInShadedArea(double x, double y); }


}
