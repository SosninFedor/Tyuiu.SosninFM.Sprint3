﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint3
{
    public interface ISprint3Task0V0 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V1 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V2 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task0V3 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task0V4 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task0V5 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task0V6 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task0V7 { double GetSumSeries(double value, int startValue, int stopValue); }    
    public interface ISprint3Task0V8 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V9 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V10 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V11 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V12 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V13 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V14 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V15 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V16 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task0V17 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task0V18 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V19 { double GetSumSeries(int startValue, int stopValue); }
    public interface ISprint3Task0V20 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V21 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V22 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V23 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V24 { double GetMultiplySeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V25 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V26 { double GetMultiplySeries(int startValue, int stopValue); }
    public interface ISprint3Task0V27 { double GetSumSeries(int value, int startValue, int stopValue); }
    public interface ISprint3Task0V28 { double GetMultiplySeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V29 { double GetSumSeries(double value, int startValue, int stopValue); }
    public interface ISprint3Task0V30 { double GetMultiplySeries(int startValue, int stopValue); }
}
