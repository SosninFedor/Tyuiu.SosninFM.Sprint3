﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tyuiu.cources.programming.interfaces.Sprint3
{
    public interface ISprint3Task7V0 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V1 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V2 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V3 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V4 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V5 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V6 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V7 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V8 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V9 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V10 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V11 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V12 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V13 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V14 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V15 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V16 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V17 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V18 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V19 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V20 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V21 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V22 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V23 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V24 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V25 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V26 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V27 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V28 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V29 { double[] GetMassFunction(int startValue, int stopValue); }
    public interface ISprint3Task7V30 { double[] GetMassFunction(int startValue, int stopValue); }
}